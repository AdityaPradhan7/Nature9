{
  "input" : [ {
    "id" : "j1_2",
    "text" : "inputDocList",
    "li_attr" : {
      "id" : "j1_2"
    },
    "a_attr" : {
      "href" : "#",
      "id" : "j1_2_anchor"
    },
    "state" : {
      "loaded" : true,
      "opened" : true,
      "selected" : false,
      "disabled" : false,
      "hidden" : false
    },
    "data" : { },
    "children" : [ {
      "id" : "j1_6",
      "text" : "Balance",
      "li_attr" : {
        "id" : "j1_6"
      },
      "a_attr" : {
        "href" : "#",
        "id" : "j1_6_anchor"
      },
      "state" : {
        "loaded" : true,
        "opened" : false,
        "selected" : false,
        "disabled" : false
      },
      "data" : {
        "guid" : "c3fccccf-78f1-4fbc-978b-1777231ebef7",
        "columnType" : "-1",
        "assignList" : [ ]
      },
      "children" : [ ],
      "type" : "number"
    }, {
      "id" : "j1_5",
      "text" : "AccountNumber",
      "li_attr" : {
        "id" : "j1_5"
      },
      "a_attr" : {
        "href" : "#",
        "id" : "j1_5_anchor"
      },
      "state" : {
        "loaded" : true,
        "opened" : false,
        "selected" : false,
        "disabled" : false
      },
      "data" : {
        "guid" : "a4716caa-3abe-4db8-a6d0-cf422c765c53",
        "columnType" : "-1"
      },
      "children" : [ ],
      "type" : "integer"
    } ],
    "type" : "documentList"
  }, {
    "id" : "j1_3",
    "text" : "txConn",
    "li_attr" : {
      "id" : "j1_3"
    },
    "a_attr" : {
      "href" : "#",
      "id" : "j1_3_anchor"
    },
    "state" : {
      "loaded" : true,
      "opened" : false,
      "selected" : false,
      "disabled" : false,
      "hidden" : false
    },
    "data" : { },
    "children" : [ ],
    "type" : "javaObject"
  }, {
    "id" : "j1_4",
    "text" : "isTxn",
    "li_attr" : {
      "id" : "j1_4"
    },
    "a_attr" : {
      "href" : "#",
      "id" : "j1_4_anchor"
    },
    "state" : {
      "loaded" : true,
      "opened" : false,
      "selected" : false,
      "disabled" : false,
      "hidden" : false
    },
    "data" : { },
    "children" : [ ],
    "type" : "boolean"
  } ],
  "output" : [ {
    "id" : "j2_1",
    "text" : "outputDocList",
    "li_attr" : {
      "id" : "j2_1"
    },
    "a_attr" : {
      "href" : "#",
      "id" : "j2_1_anchor"
    },
    "state" : {
      "loaded" : true,
      "opened" : false,
      "selected" : false,
      "disabled" : false,
      "hidden" : false
    },
    "data" : { },
    "children" : [ ],
    "type" : "documentList"
  }, {
    "id" : "j2_2",
    "text" : "rows",
    "li_attr" : {
      "id" : "j2_2"
    },
    "a_attr" : {
      "href" : "#",
      "id" : "j2_2_anchor"
    },
    "state" : {
      "loaded" : true,
      "opened" : false,
      "selected" : false,
      "disabled" : false,
      "hidden" : false
    },
    "data" : { },
    "children" : [ ],
    "type" : "integer"
  }, {
    "id" : "j2_3",
    "text" : "success",
    "li_attr" : {
      "id" : "j2_3"
    },
    "a_attr" : {
      "href" : "#",
      "id" : "j2_3_anchor"
    },
    "state" : {
      "loaded" : true,
      "opened" : false,
      "selected" : false,
      "disabled" : false,
      "hidden" : false
    },
    "data" : { },
    "children" : [ ],
    "type" : "boolean"
  }, {
    "id" : "j2_4",
    "text" : "error",
    "li_attr" : {
      "id" : "j2_4"
    },
    "a_attr" : {
      "href" : "#",
      "id" : "j2_4_anchor"
    },
    "state" : {
      "loaded" : true,
      "opened" : false,
      "selected" : false,
      "disabled" : false,
      "hidden" : false
    },
    "data" : { },
    "children" : [ ],
    "type" : "string"
  } ],
  "sql" : "VVBEQVRFIGFjY291bnRzIFNFVCBCYWxhbmNlPXtCYWxhbmNlfSBXSEVSRSBBY2NvdW50TnVtYmVyPXtBY2NvdW50TnVtYmVyfTs=",
  "version" : "v1",
  "consumers" : "",
  "developers" : "",
  "lockedByUser" : "admin"
}