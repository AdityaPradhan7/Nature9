{
  "input" : [ {
    "id" : "j1_2",
    "text" : "inputDocList",
    "li_attr" : {
      "id" : "j1_2"
    },
    "a_attr" : {
      "href" : "#",
      "id" : "j1_2_anchor"
    },
    "state" : {
      "loaded" : true,
      "opened" : true,
      "selected" : false,
      "disabled" : false,
      "hidden" : false
    },
    "data" : { },
    "children" : [ {
      "id" : "j1_5",
      "text" : "AccountHolderName",
      "li_attr" : {
        "id" : "j1_5"
      },
      "a_attr" : {
        "href" : "#",
        "id" : "j1_5_anchor"
      },
      "state" : {
        "loaded" : true,
        "opened" : false,
        "selected" : false,
        "disabled" : false
      },
      "data" : {
        "guid" : "ab3d4c1b-d326-4862-8ad4-9b4a4b717533",
        "columnType" : "-1"
      },
      "children" : [ ],
      "type" : "string"
    }, {
      "id" : "j1_6",
      "text" : "Currency",
      "li_attr" : {
        "id" : "j1_6"
      },
      "a_attr" : {
        "href" : "#",
        "id" : "j1_6_anchor"
      },
      "state" : {
        "loaded" : true,
        "opened" : false,
        "selected" : false,
        "disabled" : false
      },
      "data" : {
        "guid" : "3e605c5c-56ca-4b48-a00a-7f2404fb8022",
        "columnType" : "-1"
      },
      "children" : [ ],
      "type" : "string"
    }, {
      "id" : "j1_7",
      "text" : "DOB",
      "li_attr" : {
        "id" : "j1_7"
      },
      "a_attr" : {
        "href" : "#",
        "id" : "j1_7_anchor"
      },
      "state" : {
        "loaded" : true,
        "opened" : false,
        "selected" : false,
        "disabled" : false
      },
      "data" : {
        "guid" : "fb675d08-c29f-4726-8d3c-52e78e5c5703",
        "columnType" : "-1"
      },
      "children" : [ ],
      "type" : "date"
    }, {
      "id" : "j1_8",
      "text" : "Balance",
      "li_attr" : {
        "id" : "j1_8"
      },
      "a_attr" : {
        "href" : "#",
        "id" : "j1_8_anchor"
      },
      "state" : {
        "loaded" : true,
        "opened" : false,
        "selected" : true,
        "disabled" : false
      },
      "data" : {
        "guid" : "e2356413-dede-4c0c-acb8-4cf981359002",
        "columnType" : "-1",
        "assignList" : [ ]
      },
      "children" : [ ],
      "type" : "number"
    }, {
      "id" : "j1_9",
      "text" : "TransactionPIN",
      "li_attr" : {
        "id" : "j1_9"
      },
      "a_attr" : {
        "href" : "#",
        "id" : "j1_9_anchor"
      },
      "state" : {
        "loaded" : true,
        "opened" : false,
        "selected" : false,
        "disabled" : false
      },
      "data" : {
        "guid" : "9c1dc677-ce67-4edf-8fc8-be0823d2e770",
        "columnType" : "-1"
      },
      "children" : [ ],
      "type" : "string"
    } ],
    "type" : "documentList"
  }, {
    "id" : "j1_3",
    "text" : "txConn",
    "li_attr" : {
      "id" : "j1_3"
    },
    "a_attr" : {
      "href" : "#",
      "id" : "j1_3_anchor"
    },
    "state" : {
      "loaded" : true,
      "opened" : false,
      "selected" : false,
      "disabled" : false,
      "hidden" : false
    },
    "data" : { },
    "children" : [ ],
    "type" : "javaObject"
  }, {
    "id" : "j1_4",
    "text" : "isTxn",
    "li_attr" : {
      "id" : "j1_4"
    },
    "a_attr" : {
      "href" : "#",
      "id" : "j1_4_anchor"
    },
    "state" : {
      "loaded" : true,
      "opened" : false,
      "selected" : false,
      "disabled" : false,
      "hidden" : false
    },
    "data" : { },
    "children" : [ ],
    "type" : "boolean"
  } ],
  "output" : [ {
    "id" : "j2_1",
    "text" : "outputDocList",
    "li_attr" : {
      "id" : "j2_1"
    },
    "a_attr" : {
      "href" : "#",
      "id" : "j2_1_anchor"
    },
    "state" : {
      "loaded" : true,
      "opened" : true,
      "selected" : false,
      "disabled" : false,
      "hidden" : false
    },
    "data" : { },
    "children" : [ ],
    "type" : "documentList"
  }, {
    "id" : "j2_2",
    "text" : "rows",
    "li_attr" : {
      "id" : "j2_2"
    },
    "a_attr" : {
      "href" : "#",
      "id" : "j2_2_anchor"
    },
    "state" : {
      "loaded" : true,
      "opened" : false,
      "selected" : false,
      "disabled" : false,
      "hidden" : false
    },
    "data" : { },
    "children" : [ ],
    "type" : "integer"
  }, {
    "id" : "j2_3",
    "text" : "success",
    "li_attr" : {
      "id" : "j2_3"
    },
    "a_attr" : {
      "href" : "#",
      "id" : "j2_3_anchor"
    },
    "state" : {
      "loaded" : true,
      "opened" : false,
      "selected" : false,
      "disabled" : false,
      "hidden" : false
    },
    "data" : { },
    "children" : [ ],
    "type" : "boolean"
  }, {
    "id" : "j2_4",
    "text" : "error",
    "li_attr" : {
      "id" : "j2_4"
    },
    "a_attr" : {
      "href" : "#",
      "id" : "j2_4_anchor"
    },
    "state" : {
      "loaded" : true,
      "opened" : false,
      "selected" : false,
      "disabled" : false,
      "hidden" : false
    },
    "data" : { },
    "children" : [ ],
    "type" : "string"
  }, {
    "id" : "j2_5",
    "text" : "keys",
    "li_attr" : {
      "id" : "j2_5"
    },
    "a_attr" : {
      "href" : "#",
      "id" : "j2_5_anchor"
    },
    "state" : {
      "loaded" : true,
      "opened" : false,
      "selected" : false,
      "disabled" : false,
      "hidden" : false
    },
    "data" : {
      "guid" : "01af9d17-4d19-4f8c-ba67-f34c728304dc",
      "columnType" : "-1"
    },
    "children" : [ ],
    "type" : "integerList"
  } ],
  "sql" : "aW5zZXJ0IGludG8gYWNjb3VudHMoQWNjb3VudEhvbGRlck5hbWUsIEN1cnJlbmN5LCBET0IsIEJhbGFuY2UsVHJhbnNhY3Rpb25QSU4pIHZhbHVlcyAoe0FjY291bnRIb2xkZXJOYW1lfSwge0N1cnJlbmN5fSwge0RPQn0sIHtCYWxhbmNlfSwge1RyYW5zYWN0aW9uUElOfSk7",
  "version" : "v1",
  "consumers" : "",
  "developers" : "",
  "lockedByUser" : "admin"
}